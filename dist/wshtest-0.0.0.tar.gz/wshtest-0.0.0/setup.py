from distutils.core import setup

setup(name="wshtest", version="0.0.0", description="just test",
      packages=["RGBLed"], author="whistle")